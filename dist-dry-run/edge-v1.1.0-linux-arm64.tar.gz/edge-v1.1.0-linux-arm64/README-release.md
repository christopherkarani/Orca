# Orca/Core/Edge 1.1.0 Release Artifact

This artifact is built from commit 1f58d18 at 2026-05-16T22:40:09Z.

Verify the archive against the top-level checksums.txt before installing:

```sh
sha256sum -c checksums.txt
```

Edge materials in this release are for simulation/SITL/customer-evaluation and bench-preparation only. They are not real-flight readiness, certification, detect-and-avoid, or autopilot replacement.
