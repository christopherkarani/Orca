# Orca OpenCode and OpenClaw Plugin Plan

## Purpose

This is a lean post-Codex/Claude plan for adding OpenCode and OpenClaw plugin support to Orca.

The Codex and Claude Code plugins already established the architecture:

```text
Orca CLI is the source of truth.
Host plugins are thin wrappers.
Plugins call `orca decide`, `orca hook`, and `orca plugin doctor`.
Plugins do not duplicate policy logic.
```

This plan extends that same architecture to:

```text
OpenCode
OpenClaw
```

---

## Important Scope Boundary

Do not reopen the large core Orca roadmap.

Do not add SaaS, telemetry, monetization, hosted dashboards, or unrelated functionality.

Do not add MCP server behavior.

Do not add `.mcp.json`.

Do not add drone plugin behavior.

Do not expose drone commands, drone skills, drone demos, or operational drone-control instructions.

Do not bundle or compile the Zig Orca CLI inside the plugin packages yet.

The plugins should require:

```bash
orca
```

to be available on the user's `PATH`.

---

## Current Host Facts

### OpenCode

OpenCode plugins are JavaScript or TypeScript modules. They can be loaded from:

```text
.opencode/plugins/                # project-level
~/.config/opencode/plugins/       # global
```

or from npm packages listed in `opencode.json`:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": ["@orca/opencode-plugin"]
}
```

OpenCode plugin functions receive a context object and return hook handlers. Relevant events include:

```text
tool.execute.before
tool.execute.after
permission.asked
permission.replied
file.edited
command.executed
session.created
session.updated
session.idle
session.error
shell.env
```

### OpenClaw

OpenClaw supports plugin installation through:

```bash
openclaw plugins install <package>
openclaw plugins install npm:<package>
openclaw plugins install clawhub:<package>
openclaw plugins install git:github.com/<owner>/<repo>
openclaw plugins install <path>
```

Native OpenClaw plugins need:

```text
openclaw.plugin.json
```

and npm packages should declare an `openclaw` field in `package.json`. Packaged runtime JavaScript output should be shipped for npm installs.

---

## Phase List

| Phase | File | Goal |
|---:|---|---|
| P08B | `P08B_OPENCODE_NPM_PACKAGE.md` | Package the existing OpenCode plugin for npm distribution |
| P09 | `P09_OPENCLAW_PLUGIN.md` | Build native OpenClaw plugin wrapper |
| P10 | `P10_OPENCLAW_NPM_PACKAGE.md` | Package OpenClaw plugin for npm installs |
| P11 | `P11_CLAWHUB_SUBMISSION.md` | Prepare ClawHub submission |

---

## Recommended Order

```text
P08B -> P09 -> P10 -> P11
```

Do OpenCode npm first because P08 already created OpenCode local-plugin support.

Then build OpenClaw as its own host integration.

---

## Expected Final Distribution

### OpenCode

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": ["@orca/opencode-plugin"]
}
```

### OpenClaw

```bash
openclaw plugins install npm:@orca/openclaw-plugin
```

Later:

```bash
openclaw plugins install clawhub:orca
```

---

## References

- OpenCode plugin docs: https://opencode.ai/docs/plugins/
- OpenClaw plugin CLI docs: https://docs.openclaw.ai/tools/plugin
- OpenClaw native plugin docs: https://docs.openclaw.ai/cli/plugins
- OpenClaw plugin publishing docs: https://docs.openclaw.ai/plugins/building-plugins
- OpenClaw package metadata docs: https://docs.openclaw.ai/plugins/sdk-setup
- ClawHub docs: https://docs.openclaw.ai/clawhub
