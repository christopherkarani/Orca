# P01 — Aegis CLI Plugin Surface

## Objective

Make the Aegis CLI itself a first-class plugin surface.

At the end of this phase, Aegis should expose stable plugin-oriented commands that host plugins can call without duplicating policy logic.

---

## Effort

**Recommended effort:** High

This phase defines the foundation for all host plugins.

---

## Core Idea

Aegis should become plugin-capable through its own CLI:

```bash
aegis plugin doctor
aegis plugin doctor codex
aegis plugin doctor claude
aegis plugin manifest codex
aegis plugin manifest claude
aegis plugin install codex
aegis plugin install claude
aegis plugin mcp-server
```

Host-specific plugins should call these commands instead of embedding Aegis logic.

---

## Scope

Implement:

- `aegis plugin` command namespace
- `aegis plugin doctor`
- `aegis plugin manifest`
- `aegis plugin install`
- `aegis plugin mcp-server` or equivalent safe MCP plugin server
- plugin request/response schemas
- safe read-only Aegis MCP tools
- plugin documentation
- drone-aware plugin safety checks

---

## Non-goals

Do not build Codex or Claude plugin packages yet.

Do not add SaaS or telemetry.

Do not expose drone actuation tools as default MCP tools.

Do not auto-modify user host configs without explicit confirmation.

---

## CLI Commands

### `aegis plugin doctor`

```bash
aegis plugin doctor
aegis plugin doctor codex
aegis plugin doctor claude
```

Report:

- Aegis version
- Aegis binary path
- policy found/missing
- audit/replay status
- MCP status
- plugin directories found/missing
- host binary found/missing
- drone workstream detected yes/no
- drone-safety mode active yes/no
- security warnings

Must not print raw env vars or secrets.

### `aegis plugin manifest`

```bash
aegis plugin manifest codex
aegis plugin manifest claude
aegis plugin manifest all
```

Behavior:

- print or locate the manifest for each plugin
- validate local plugin manifest if present
- output JSON with paths and validation status when `--json` is provided

### `aegis plugin install`

```bash
aegis plugin install codex
aegis plugin install claude
aegis plugin install all
```

Behavior:

- install from local repo path when possible
- or print exact safe instructions if host install command is not available
- never silently overwrite user config
- require explicit confirmation unless `--yes`
- support `--dry-run`
- support `--path <plugin-path>`

### `aegis plugin mcp-server`

Expose safe Aegis CLI functions as MCP tools.

Suggested tools:

- `aegis_doctor`
- `aegis_policy_check`
- `aegis_policy_explain`
- `aegis_redteam`
- `aegis_replay_summary`
- `aegis_capabilities`
- `aegis_drone_safety_status`

Dangerous or mutating tools should be excluded by default.

Do not expose:

- live drone actuation
- arbitrary shell execution
- arbitrary file writes
- raw audit log dumping without redaction
- raw secret values
- policy changes without explicit approval

---

## Drone-aware Safety Checks

If drone modules are detected, plugin doctor should show:

```text
Drone workstream: detected
Drone safety: plugin default-deny for live-control patterns
Simulation demos: allowed
Live control: requires explicit policy and user approval
```

Add high-risk pattern names generically, without operational guidance:

- arm
- disarm
- takeoff
- land
- motor
- actuator
- mission upload
- live vehicle connection
- flight-critical parameter change

---

## Schemas

Create:

```text
integrations/common/schemas/aegis-plugin-request-v1.json
integrations/common/schemas/aegis-plugin-response-v1.json
```

These should support plugin doctor, manifest, install, MCP tool requests, and host decision calls.

---

## Tests

Add tests for:

- `aegis plugin doctor`
- `aegis plugin doctor --json`
- `aegis plugin doctor codex`
- `aegis plugin doctor claude`
- missing host binary is reported clearly
- fake host binary detection
- drone workstream detection if test fixture exists
- no raw env values printed
- `aegis plugin manifest codex` before plugin exists reports missing clearly
- `aegis plugin install --dry-run codex`
- MCP server exposes only safe tools
- MCP server does not expose drone actuation tools
- fake secrets do not appear in plugin doctor output

---

## Acceptance Criteria

- `aegis plugin` namespace exists.
- Plugin doctor works.
- Plugin manifest command works.
- Plugin install dry-run works.
- Safe Aegis MCP plugin server exists or is clearly stubbed with documented deferred behavior.
- Drone safety detection/warnings exist.
- No secrets leak.
- Existing drone and Aegis tests still pass.

---

## Codex Execution Prompt

```text
Implement P01: Aegis CLI Plugin Surface.

Make the Aegis CLI itself plugin-capable by adding `aegis plugin doctor`, `aegis plugin manifest`, `aegis plugin install`, and safe `aegis plugin mcp-server` behavior. Include drone-aware safety reporting, but do not expose live drone actuation tools.

Run:
- zig build
- zig build test
- ./zig-out/bin/aegis plugin doctor
- ./zig-out/bin/aegis plugin install codex --dry-run
- existing drone tests if present

Recommended effort: High.
```
