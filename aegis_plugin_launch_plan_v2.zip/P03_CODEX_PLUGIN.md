# P03 — Codex Plugin

## Objective

Build the Aegis Codex plugin package.

At the end of this phase, Codex users should be able to install or load the Aegis plugin locally, run Aegis skills, and have Codex lifecycle hooks call the Aegis CLI.

---

## Effort

**Recommended effort:** Medium-High

Use High if hooks actively block tool use.

---

## Current Codex Plugin Facts

Codex plugins use a manifest at:

```text
.codex-plugin/plugin.json
```

Plugin components such as `skills/`, `.mcp.json`, and `hooks/hooks.json` live at the plugin root.

Repo marketplace installation can use:

```text
.agents/plugins/marketplace.json
```

and plugin folders under:

```text
plugins/
```

Adjust exact commands to current Codex behavior during implementation.

---

## Scope

Implement:

- Codex plugin directory
- `.codex-plugin/plugin.json`
- skills
- hooks config
- optional `.mcp.json`
- Codex repo marketplace entry if useful
- README
- tests
- drone-safety skill

---

## Directory

```text
integrations/codex-plugin/
  .codex-plugin/
    plugin.json
  skills/
    aegis-doctor/
      SKILL.md
    aegis-init/
      SKILL.md
    aegis-protect/
      SKILL.md
    aegis-redteam/
      SKILL.md
    aegis-replay/
      SKILL.md
    aegis-drone-safety/
      SKILL.md
  hooks/
    hooks.json
  .mcp.json
  README.md
```

---

## Skills

Create skills:

- `aegis-doctor`
- `aegis-init`
- `aegis-protect`
- `aegis-redteam`
- `aegis-replay`
- `aegis-drone-safety`

The drone-safety skill must:

- explain simulation-only plugin demos
- call `aegis plugin doctor` or `aegis decide drone` examples
- never provide operational drone-control instructions
- remind that live drone operations require explicit policy and human approval

---

## Hooks

Codex hooks should call:

```bash
aegis hook codex <Event>
```

Events:

- `SessionStart`
- `UserPromptSubmit`
- `PreToolUse`
- `PermissionRequest`
- `PostToolUse`
- `Stop`

Do not duplicate policy logic.

---

## MCP Config

If `.mcp.json` is included, it should point to safe Aegis plugin tools, for example:

```bash
aegis plugin mcp-server
```

Do not expose mutating drone tools by default.

---

## Security Requirements

- No secrets in plugin files.
- Hook output host-valid.
- Human logs to stderr.
- Aegis CLI remains source of truth.
- Plugin docs say `aegis run` is stronger than hooks alone.
- Drone actuation is blocked/critical by default.
- No real drone demos.
- No telemetry.

---

## Tests

Add tests for:

- manifest exists
- skills exist
- hooks call `aegis hook codex`
- `.mcp.json` valid if present
- no secrets in plugin files
- drone-safety skill exists and does not contain operational drone-control instructions
- fake Codex hook payloads work
- plugin README includes limitations

---

## Acceptance Criteria

- Codex plugin directory exists.
- Manifest validates or passes schema-lite tests.
- Skills exist.
- Hooks call Aegis.
- MCP config uses safe Aegis plugin server if included.
- Drone safety skill exists.
- No secrets leak.
- Local install docs exist.

---

## Codex Execution Prompt

```text
Implement P03: Codex Plugin.

Build the Codex plugin package under integrations/codex-plugin. Use .codex-plugin/plugin.json, root-level skills, hooks/hooks.json, optional .mcp.json, README, and tests. Hooks must call `aegis hook codex`. Include an Aegis drone-safety skill that does not provide operational drone-control instructions.

Run:
- zig build
- zig build test
- plugin structure tests
- fake Codex hook tests

Recommended effort: Medium-High.
```
