# Prompts for Revised Plugin Phases

## General Prefix

```text
You are implementing Aegis plugin work.

Important context:
- Do not assume we are simply continuing from the original Phase 22 roadmap.
- The current repo may include additional drone-related work.
- Treat drone-related functionality as safety-sensitive.
- Aegis CLI itself should become a plugin-capable surface.
- Host plugins must call the Aegis CLI and must not duplicate policy logic.
- Do not add SaaS, telemetry by default, monetization, hosted dashboards, or unrelated features.
- Do not provide operational drone-control instructions.
- Plugins must not claim stronger enforcement than the host supports.
```

## P00

```text
[General Prefix]

Implement P00 using P00_CURRENT_BASELINE_AND_DRONE_SAFEPOINT.md.

Recommended effort: High.
```

## P01

```text
[General Prefix]

Implement P01 using P01_AEGIS_CLI_PLUGIN_SURFACE.md.

Recommended effort: High.
```

## P02

```text
[General Prefix]

Implement P02 using P02_AGENT_HOST_INTEGRATION_API.md.

Recommended effort: High.
```

## P03

```text
[General Prefix]

Implement P03 using P03_CODEX_PLUGIN.md.

Recommended effort: Medium-High.
```

## P04

```text
[General Prefix]

Implement P04 using P04_CLAUDE_CODE_PLUGIN.md.

Recommended effort: High.
```

## P05

```text
[General Prefix]

Implement P05 using P05_PLUGIN_SECURITY_AND_DRONE_REGRESSION.md.

Recommended effort: High.
```

## P06

```text
[General Prefix]

Implement P06 using P06_PLUGIN_DISTRIBUTION_AND_MARKETPLACE.md.

Recommended effort: Medium.
```

## P07

```text
[General Prefix]

Implement P07 using P07_PLUGIN_LAUNCH_AND_POSTLAUNCH.md.

Recommended effort: Medium.
```
