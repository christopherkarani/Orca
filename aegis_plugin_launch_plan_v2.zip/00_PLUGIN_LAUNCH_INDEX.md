# Aegis Plugin Launch Plan v2

**Project:** Aegis CLI plugin surface + Codex plugin + Claude Code plugin  
**Starting point:** The current Aegis repository, not an assumed Phase 22/v1-only state  
**Important context:** A separate drone workstream is happening in the same Aegis codebase  
**Goal:** Make Aegis usable as a plugin-native tool inside Codex and Claude Code, while preserving the Aegis CLI as the enforcement and integration source of truth  
**Scope:** Local-first plugins and CLI integration surfaces only; no SaaS, telemetry, monetization, hosted dashboards, or enterprise control plane.

---

## Why This Plan Exists

The first plugin plan assumed Aegis was cleanly continuing from the original Phase 22 v1.0 roadmap. That is no longer the right assumption.

The real situation is:

1. Aegis core exists in some current repo state.
2. Additional drone-related work is taking place.
3. We still want Codex and Claude Code plugins.
4. We also want **Aegis CLI itself to become a plugin surface**, not just a tool called by plugins.

This revised plan starts with a baseline inventory phase so Codex agents do not accidentally break the drone workstream or depend on old roadmap assumptions.

---

## Strategic Product Shape

Aegis should have three layers:

```text
Aegis CLI/Core
  The policy engine, redaction engine, audit/replay system, command guard, MCP proxy,
  drone-aware safety classification, and plugin runtime.

Aegis CLI Plugin Surface
  Stable commands and schemas that let agent hosts call Aegis as a plugin:
  decide, hook, plugin doctor, plugin manifest, plugin install, plugin MCP server.

Host Plugins
  Codex plugin and Claude Code plugin packages that expose Aegis as native skills,
  hooks, and MCP helper tools inside those hosts.
```

The Aegis CLI remains the source of truth. Plugins must not duplicate policy logic.

---

## The New Architectural Decision

Do not think of the plugins as only:

```text
Codex plugin
Claude Code plugin
```

Think of the product as:

```text
Aegis as a plugin-capable CLI
Aegis plugin for Codex
Aegis plugin for Claude Code
```

This means the repo should gain an Aegis plugin namespace:

```bash
aegis plugin doctor
aegis plugin doctor codex
aegis plugin doctor claude
aegis plugin manifest codex
aegis plugin manifest claude
aegis plugin install codex
aegis plugin install claude
aegis plugin mcp-server
aegis decide command
aegis decide file
aegis decide mcp
aegis decide prompt
aegis hook codex <event>
aegis hook claude <event>
```

The host plugins should mostly be packaging around these commands.

---

## Drone Workstream Rule

The plugin work must treat drone-related functionality as safety-sensitive.

Plugins must not:

- enable live drone actuation by default
- auto-approve drone-control commands
- include drone demos that operate real hardware
- store or print drone credentials, telemetry secrets, or connection strings
- bypass policy checks for drone modules
- weaken existing drone tests or safety checks

Plugins may:

- detect that drone modules are present
- classify drone actuation commands as critical risk
- support simulation-only demos
- expose policy guidance for drone-related Aegis sessions
- require explicit policy and user approval for safety-critical operations

---

## Phase List

| Phase | File | Goal | Effort |
|---:|---|---|---|
| P00 | `P00_CURRENT_BASELINE_AND_DRONE_SAFEPOINT.md` | Inspect current repo, map Aegis + drone state, define safe integration baseline | High |
| P01 | `P01_AEGIS_CLI_PLUGIN_SURFACE.md` | Make the Aegis CLI itself plugin-capable | High |
| P02 | `P02_AGENT_HOST_INTEGRATION_API.md` | Add host hook/decision JSON contracts for Codex and Claude | High |
| P03 | `P03_CODEX_PLUGIN.md` | Build Codex plugin package | Medium-High |
| P04 | `P04_CLAUDE_CODE_PLUGIN.md` | Build Claude Code plugin package | High |
| P05 | `P05_PLUGIN_SECURITY_AND_DRONE_REGRESSION.md` | Test plugins, secret safety, host payloads, and drone-safety regressions | High |
| P06 | `P06_PLUGIN_DISTRIBUTION_AND_MARKETPLACE.md` | Package plugins, release artifacts, Claude marketplace, Codex install path | Medium |
| P07 | `P07_PLUGIN_LAUNCH_AND_POSTLAUNCH.md` | Launch, triage, patch, and collect feedback | Medium |

---

## Desired Repository Layout

Final layout should look like:

```text
integrations/
  README.md
  common/
    schemas/
      aegis-plugin-request-v1.json
      aegis-plugin-response-v1.json
      hook-request-v1.json
      hook-response-v1.json
      host-capabilities-v1.json
    docs/
      integration-api.md
      host-output-mapping.md
      drone-safety-notes.md
  codex-plugin/
    .codex-plugin/
      plugin.json
    skills/
      aegis-doctor/
        SKILL.md
      aegis-init/
        SKILL.md
      aegis-protect/
        SKILL.md
      aegis-redteam/
        SKILL.md
      aegis-replay/
        SKILL.md
      aegis-drone-safety/
        SKILL.md
    hooks/
      hooks.json
    .mcp.json
    README.md
  claude-code-plugin/
    .claude-plugin/
      plugin.json
    skills/
      doctor/
        SKILL.md
      init/
        SKILL.md
      protect/
        SKILL.md
      redteam/
        SKILL.md
      replay/
        SKILL.md
      drone-safety/
        SKILL.md
    hooks/
      hooks.json
    .mcp.json
    README.md
  claude-marketplace/
    .claude-plugin/
      marketplace.json
    README.md

docs/
  integrations/
    aegis-cli-plugin.md
    codex.md
    claude-code.md
    plugin-security-model.md
    plugin-troubleshooting.md
    drone-safety.md
```

---

## Success Criteria

The plan is complete when:

### Aegis CLI Plugin Surface

- `aegis plugin doctor` works.
- `aegis plugin manifest codex` can emit or locate the Codex plugin manifest.
- `aegis plugin manifest claude` can emit or locate the Claude plugin manifest.
- `aegis plugin install codex` provides a safe install path or clear instructions.
- `aegis plugin install claude` provides a safe install path or clear instructions.
- `aegis plugin mcp-server` exposes safe Aegis CLI functions as MCP tools where appropriate.
- `aegis decide` and `aegis hook` are stable and schema-documented.

### Codex Plugin

- Plugin manifest exists at `.codex-plugin/plugin.json`.
- Skills exist for doctor, init, protect, redteam, replay, and drone safety.
- Hooks call `aegis hook codex`.
- MCP config points to safe Aegis plugin tools where appropriate.
- Local install docs work.
- Limitations are clear.

### Claude Code Plugin

- Plugin manifest exists at `.claude-plugin/plugin.json`.
- Skills exist for doctor, init, protect, redteam, replay, and drone safety.
- Hooks call `aegis hook claude`.
- Claude marketplace file exists.
- Local and marketplace install docs work.
- Limitations are clear.

### Safety

- Fake secrets do not leak.
- Drone safety-critical commands are classified as critical.
- Plugin demos do not operate real drones.
- CI never prompts.
- Host hooks do not claim more enforcement than the host supports.
- Existing drone tests and core Aegis tests still pass.

---

## Recommended Execution

Do not start by building plugin directories.

Start with:

```text
P00_CURRENT_BASELINE_AND_DRONE_SAFEPOINT.md
```

That phase forces Codex to inspect the actual repo state, detect the drone workstream, and produce a baseline map before modifying architecture.

Then proceed:

```text
P01 -> P02 -> P03 -> P04 -> P05 -> P06 -> P07
```
