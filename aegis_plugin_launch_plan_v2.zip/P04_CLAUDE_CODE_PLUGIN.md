# P04 — Claude Code Plugin

## Objective

Build the Aegis Claude Code plugin package.

At the end of this phase, Claude Code users should be able to install the Aegis plugin locally or through a marketplace catalog, run Aegis skills, and have Claude Code hooks call the Aegis CLI.

---

## Effort

**Recommended effort:** High

Claude Code hooks can return decisions, so output correctness matters.

---

## Current Claude Code Plugin Facts

Claude Code plugins use:

```text
.claude-plugin/plugin.json
```

Plugin components such as `skills/`, `commands/`, `agents/`, `hooks/`, and `.mcp.json` live at plugin root.

Claude Code plugin marketplaces use:

```text
.claude-plugin/marketplace.json
```

A marketplace file defines a catalog of plugins with source locations.

---

## Scope

Implement:

- Claude Code plugin directory
- `.claude-plugin/plugin.json`
- skills
- hooks config
- optional `.mcp.json`
- marketplace file
- README
- tests
- drone-safety skill

---

## Directory

```text
integrations/claude-code-plugin/
  .claude-plugin/
    plugin.json
  skills/
    doctor/
      SKILL.md
    init/
      SKILL.md
    protect/
      SKILL.md
    redteam/
      SKILL.md
    replay/
      SKILL.md
    drone-safety/
      SKILL.md
  hooks/
    hooks.json
  .mcp.json
  README.md
```

Marketplace:

```text
integrations/claude-marketplace/
  .claude-plugin/
    marketplace.json
  README.md
```

---

## Skills

User-facing skills should be documented as:

```text
/aegis:doctor
/aegis:init
/aegis:protect
/aegis:redteam
/aegis:replay
/aegis:drone-safety
```

The exact namespace depends on plugin name.

---

## Hooks

Claude hooks should call:

```bash
aegis hook claude <Event>
```

Events:

- `SessionStart`
- `UserPromptSubmit`
- `PreToolUse`
- `PermissionRequest`
- `PostToolUse`
- `SessionEnd`

Use matchers for:

- Bash/shell tools
- file write/edit tools
- MCP tools
- prompt submissions

---

## Drone Safety

The plugin should default to:

- simulation-only examples
- critical risk classification for live-control patterns
- no operational control instructions
- clear guidance that live drone actions require explicit policy and human approval

---

## Security Requirements

- No secrets in plugin files.
- Hook output valid for Claude Code.
- Debug logs to stderr.
- Raw tool output not persisted by default.
- Aegis CLI remains source of truth.
- `aegis run` described as strongest local runtime protection.
- Drone actuation blocked/critical by default.
- No telemetry.

---

## Tests

Add tests for:

- manifest exists
- skills exist
- hooks call `aegis hook claude`
- `.mcp.json` valid if present
- marketplace file exists and validates schema-lite
- fake Claude hook payloads work
- fake secret prompt is redacted/blocked/warned
- dangerous command is denied or warned according to policy
- drone actuation payload classified critical
- no secrets in plugin artifacts
- README includes limitations

---

## Acceptance Criteria

- Claude plugin directory exists.
- Manifest validates or passes schema-lite tests.
- Skills exist.
- Hooks call Aegis.
- Marketplace file exists.
- Drone safety skill exists.
- No secrets leak.
- Local and marketplace install docs exist.

---

## Codex Execution Prompt

```text
Implement P04: Claude Code Plugin.

Build integrations/claude-code-plugin and integrations/claude-marketplace. Use .claude-plugin/plugin.json, root-level skills, hooks/hooks.json, optional .mcp.json, README, marketplace catalog, and tests. Hooks must call `aegis hook claude`. Include an Aegis drone-safety skill that does not provide operational drone-control instructions.

Run:
- zig build
- zig build test
- plugin structure tests
- fake Claude hook tests
- marketplace schema-lite tests

Recommended effort: High.
```
