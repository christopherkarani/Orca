# Drone Workstream Guardrails for Plugin Work

## Core Rule

Drone-related functionality is safety-sensitive. Plugin work must not weaken it.

---

## Default Plugin Behavior

The plugins should default to:

- simulation-only examples
- live-control classification as critical risk
- explicit policy requirement for safety-critical operations
- no real drone hardware in tests
- no operational drone-control instructions in plugin docs
- no auto-approval of live-control commands

---

## Risk Patterns

Classify as critical by default when context suggests live drone operation:

- arming or disarming
- takeoff or landing
- motor or actuator commands
- mission upload
- navigation commands
- live vehicle connection
- flight-critical parameter changes

These are pattern classes, not operational instructions.

---

## Documentation Wording

Use wording like:

```text
Aegis detected drone-related functionality. Plugin demos are simulation-only. Live drone operations require explicit policy, human approval, and appropriate safety procedures outside the plugin.
```

Avoid wording that tells agents how to operate drones.

---

## Tests

Add tests for:

- simulation-only drone fixture
- live-control pattern classified critical
- ambiguous drone command fails closed in strict/ci
- plugin MCP server does not expose live-control tools by default
- docs do not include operational drone-control instructions
