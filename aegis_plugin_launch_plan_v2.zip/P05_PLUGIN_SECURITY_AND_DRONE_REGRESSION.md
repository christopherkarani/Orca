# P05 — Plugin Security and Drone Regression

## Objective

Build a security and compatibility test suite for the Aegis plugin surface, Codex plugin, Claude Code plugin, and drone-safety integration.

---

## Effort

**Recommended effort:** High

This phase prevents unsafe plugin claims and drone regressions.

---

## Scope

Implement:

- plugin fixture tests
- fake Codex payloads
- fake Claude payloads
- plugin artifact secret scans
- drone safety regression tests
- docs overclaim checks
- hook timeout/invalid input tests
- optional host validation tests

---

## Fixtures

Create:

```text
tests/plugin-fixtures/
  codex/
  claude/
  drone/
```

Drone fixtures should be simulation-only and must not control real hardware.

---

## Required Tests

### Plugin Structure

- Codex manifest exists.
- Claude manifest exists.
- Skills exist.
- Hooks exist.
- MCP configs valid if present.
- Marketplace file valid if present.

### Hook Behavior

- safe shell command allowed
- dangerous shell command denied/warned
- fake secret prompt redacted/blocked/warned
- risky MCP tool denied/warned
- protected file write denied/warned
- invalid payload fails safely
- oversized payload fails safely
- stdout/stderr separation preserved
- CI mode never prompts

### Drone Safety

- live-control pattern classified critical
- simulation/status pattern not classified as live actuation
- ambiguous drone command fails closed in strict/ci
- plugin docs do not include operational drone-control instructions
- plugin MCP server does not expose drone actuation tools by default
- existing drone tests still pass

### Secret Safety

Scan:

- plugin files
- generated hook responses
- audit logs
- replay output
- docs
- marketplace files
- plugin packages

No fake secrets should appear.

### Overclaim Checks

Docs must not claim:

- perfect sandboxing
- universal transparent file enforcement
- universal transparent network enforcement
- protection for agents not launched through Aegis
- protection against root/admin/kernel compromise
- live drone control safety without explicit policy and human approval

---

## Optional Local Host Tests

If Codex is installed:

- validate local plugin install if supported
- run plugin doctor skill if feasible

If Claude Code is installed:

- run plugin validation if available
- test local plugin install or marketplace add if feasible

Skip cleanly if host tools are not installed.

---

## Acceptance Criteria

- Security tests pass.
- Drone-safety tests pass.
- No secrets leak.
- Existing Aegis tests pass.
- Existing drone tests pass or unsupported reasons documented.
- Docs are honest.
- Plugin artifacts are safe to package.

---

## Codex Execution Prompt

```text
Implement P05: Plugin Security and Drone Regression.

Add plugin security fixtures, fake host payload tests, secret scans, docs overclaim checks, and drone-safety regression tests. Ensure the plugins never expose live drone actuation tools by default and never leak fake secrets.

Run:
- zig build
- zig build test
- plugin fixture tests
- existing drone tests if present
- secret scan over plugin artifacts and docs

Recommended effort: High.
```
