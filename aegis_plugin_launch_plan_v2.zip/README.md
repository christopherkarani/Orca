# Aegis Plugin Launch Plan v2

This revised plan no longer assumes the old Phase 22/v1-only baseline.

It accounts for:

- the current Aegis repository state
- the drone workstream
- Codex and Claude Code plugins
- the new requirement that Aegis CLI itself becomes a plugin-capable surface

Start with:

1. `00_PLUGIN_LAUNCH_INDEX.md`
2. `P00_CURRENT_BASELINE_AND_DRONE_SAFEPOINT.md`
3. `AEGIS_CLI_PLUGIN_CONTRACT.md`
4. `DRONE_WORKSTREAM_GUARDRAILS.md`
5. `PLUGIN_SECURITY_MODEL.md`

Then execute P00 through P07 in order.
