# P02 — Agent Host Integration API

## Objective

Add the stable decision and hook API used by Codex and Claude Code plugins.

At the end of this phase, host plugins should be able to call Aegis through JSON-based commands for decisions, hooks, redaction, and audit-safe responses.

---

## Effort

**Recommended effort:** High

This API is the boundary between agent hosts and Aegis.

---

## Scope

Implement:

- `aegis decide`
- `aegis hook`
- host input normalization
- host output adapters
- hook request/response schemas
- Codex hook adapter
- Claude Code hook adapter
- drone-aware risk classification in decision output
- tests with fake host payloads

---

## Non-goals

Do not build the host plugin directories yet.

Do not duplicate the policy engine.

Do not make host hooks more powerful than the host supports.

Do not add SaaS or telemetry.

---

## CLI Surface

### `aegis decide`

```bash
aegis decide command --json <payload>
aegis decide file --json <payload>
aegis decide mcp --json <payload>
aegis decide prompt --json <payload>
aegis decide drone --json <payload>
```

Also support stdin:

```bash
cat payload.json | aegis decide command --stdin
```

### `aegis hook`

```bash
aegis hook codex SessionStart
aegis hook codex UserPromptSubmit
aegis hook codex PreToolUse
aegis hook codex PermissionRequest
aegis hook codex PostToolUse
aegis hook codex Stop

aegis hook claude SessionStart
aegis hook claude UserPromptSubmit
aegis hook claude PreToolUse
aegis hook claude PermissionRequest
aegis hook claude PostToolUse
aegis hook claude SessionEnd
```

Hook command behavior:

1. Read JSON from stdin.
2. Bound input size.
3. Normalize host payload.
4. Redact sensitive data.
5. Evaluate decision.
6. Emit host-valid response to stdout.
7. Emit human/debug logs only to stderr.
8. Persist audit events only after redaction.

---

## Drone Decision Type

Add a drone decision type because the repo now has a drone workstream.

```bash
aegis decide drone --json <payload>
```

This should classify safety-critical drone-related operations.

Default decisions:

- simulation/status/read-only: allow or ask according to policy
- live actuation/control: critical risk, deny or ask according to explicit policy
- ambiguous drone commands: fail closed in strict/ci
- CI mode: ask becomes deny

Do not include operational drone instructions in output. Keep output policy-focused.

---

## Schemas

Create:

```text
integrations/common/schemas/hook-request-v1.json
integrations/common/schemas/hook-response-v1.json
integrations/common/schemas/host-capabilities-v1.json
```

Decision output should include:

```json
{
  "version": 1,
  "decision": "block",
  "risk": "critical",
  "category": "drone.actuation",
  "reason": "live drone-control pattern requires explicit policy",
  "rule": "drone.default",
  "message": "Blocked by Aegis: safety-critical drone operation is not allowed by current policy.",
  "redactions": []
}
```

---

## Host Adapter Rules

### Codex

Codex plugins can contain skills, MCP config, and hooks. Codex hook behavior can be host-limited, so the adapter must not claim total enforcement if the host only treats a hook as advisory.

### Claude Code

Claude Code supports plugin packaging and decision-bearing hooks. The adapter should emit valid Claude Code hook outputs for events it handles.

---

## Security Requirements

- Raw secrets must never be persisted.
- Hook stdout must be host-valid.
- Debug output goes to stderr.
- CI mode never prompts.
- Drone live-control patterns default to deny/critical unless explicitly allowed.
- Ambiguous drone commands fail closed in strict/ci.
- Invalid host JSON fails safely.
- Oversized host JSON fails safely.
- Host limitations are reported honestly.
- No real drone hardware in tests.

---

## Tests

Add tests for:

- safe command decision
- dangerous command decision
- prompt with fake secret
- MCP risky tool decision
- drone simulation/status decision
- drone actuation command classified critical
- ambiguous drone command fails closed in strict/ci
- Codex fake `PreToolUse`
- Codex fake `UserPromptSubmit`
- Claude fake `PreToolUse`
- Claude fake `UserPromptSubmit`
- invalid JSON
- oversized JSON
- secret redaction
- stdout/stderr separation
- CI ask-to-deny

---

## Acceptance Criteria

- `aegis decide` works for command, file, mcp, prompt, and drone.
- `aegis hook codex PreToolUse` works with fake payload.
- `aegis hook claude PreToolUse` works with fake payload.
- Drone safety-critical decisions default to critical/deny or ask according to explicit policy.
- No fake secrets leak.
- Existing drone tests still pass.

---

## Codex Execution Prompt

```text
Implement P02: Agent Host Integration API.

Add `aegis decide` and `aegis hook` commands for Codex and Claude Code plugins. Include host JSON schemas, host adapters, redaction, audit-safe behavior, and drone-aware risk classification.

Run:
- zig build
- zig build test
- fake Codex hook tests
- fake Claude hook tests
- drone decision tests
- existing drone tests if present

Recommended effort: High.
```
