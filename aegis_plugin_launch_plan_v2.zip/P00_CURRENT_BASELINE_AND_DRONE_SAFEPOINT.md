# P00 — Current Baseline and Drone Safepoint

## Objective

Inspect the current Aegis repository and establish a safe baseline for plugin work.

This phase replaces the old assumption that we are simply continuing from Phase 22. The current repo may include drone-related work, and plugins must not break or bypass it.

---

## Effort

**Recommended effort:** High

This is a discovery and guardrail phase. It prevents Codex from building plugins against stale assumptions.

---

## Scope

Implement or produce:

- repository inventory
- current Aegis CLI command map
- current policy/audit/security module map
- current drone module/workstream map
- existing tests and CI map
- plugin readiness report
- drone-safety integration constraints
- baseline smoke test script if missing
- no major feature changes unless required for safe discovery

---

## Non-goals

Do not build Codex or Claude plugins yet.

Do not refactor major modules.

Do not change drone behavior unless a test is clearly broken.

Do not add monetization, SaaS, hosted services, or telemetry.

---

## Required Investigation

Codex should inspect the repo and document:

### Aegis Core

- CLI commands currently available.
- Policy engine location and API.
- Audit/replay location and API.
- Redaction location and API.
- MCP support status.
- Command guard status.
- Network guard status.
- Filesystem staging status.
- Platform backend status.
- Tests available.

### Drone Workstream

Document whether the repo contains any drone-related:

- commands
- modules
- policies
- tests
- docs
- configs
- connection logic
- simulation/demo logic
- safety checks

Do not infer operational details beyond what is present. The goal is to avoid breaking or bypassing the workstream.

### Plugin Readiness

Document whether the repo already has:

- `aegis decide`
- `aegis hook`
- `aegis plugin`
- MCP server mode
- plugin docs
- integration schemas
- host plugin directories

---

## Drone Safety Rules

If drone-related functionality exists, mark it as safety-sensitive.

The plugin architecture must default to:

- classify live drone actuation as critical risk
- allow simulation-only workflows with clear labeling
- block or require explicit policy for commands that appear to arm, take off, land, actuate, navigate, upload missions, connect to live vehicles, or change flight-critical parameters
- never use real drone hardware in plugin tests
- never store or print drone credentials or connection strings
- never auto-approve drone-related high-risk operations

---

## Deliverables

Create:

```text
docs/integrations/current-baseline.md
docs/integrations/drone-safepoint.md
```

Optional if useful:

```text
scripts/plugin-baseline-smoke-test.sh
scripts/plugin-baseline-smoke-test.ps1
```

`current-baseline.md` should include:

- current CLI map
- current modules
- current tests
- missing pieces
- plugin prerequisites
- recommended next phase status

`drone-safepoint.md` should include:

- detected drone-related files/modules
- safety-sensitive commands or patterns
- tests that must continue to pass
- plugin restrictions
- simulation-only demo rule

---

## Tests

Run existing tests:

```bash
zig build
zig build test
```

Also run whatever current project smoke tests exist:

```bash
./zig-out/bin/aegis --help
./zig-out/bin/aegis doctor
```

If drone-specific tests exist, run them or document why they cannot run.

---

## Acceptance Criteria

- Current repo state is documented.
- Drone workstream is identified or explicitly marked not detected.
- Existing Aegis tests pass or failures are documented.
- Existing drone tests pass or failures are documented.
- Plugin prerequisites are documented.
- No plugin implementation starts yet.
- No drone functionality is weakened.
- Next phase has a reliable baseline.

---

## Codex Execution Prompt

```text
Implement P00: Current Baseline and Drone Safepoint.

Do not build the plugins yet. Inspect the current Aegis repo and produce a baseline report, including current CLI commands, modules, tests, and any drone-related workstream. Treat drone-related functionality as safety-sensitive. Do not change drone behavior except to add documentation or safe smoke-test wrappers.

Run:
- zig build
- zig build test
- ./zig-out/bin/aegis --help if available
- ./zig-out/bin/aegis doctor if available
- drone-specific tests if present

Produce docs/integrations/current-baseline.md and docs/integrations/drone-safepoint.md.

Recommended effort: High.
```
