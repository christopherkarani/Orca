# Aegis CLI Plugin Contract

## Purpose

This document defines what it means for the Aegis CLI to become a plugin surface.

Aegis is not only a binary that host plugins call. It should provide stable plugin commands and schemas so any agent host can integrate with it.

---

## Required Commands

```bash
aegis plugin doctor
aegis plugin manifest <host>
aegis plugin install <host>
aegis plugin mcp-server
aegis decide <kind>
aegis hook <host> <event>
```

---

## Plugin Invariants

1. The Aegis CLI is the source of truth.
2. Host plugins do not duplicate the policy engine.
3. All plugin input is untrusted.
4. All plugin output is bounded.
5. Redaction happens before persistence.
6. Hook stdout must be valid for the host.
7. Human logs go to stderr.
8. CI mode never prompts.
9. Drone live-control actions are critical risk by default.
10. Plugins never claim stronger enforcement than the host supports.

---

## Safe MCP Tools

`aegis plugin mcp-server` may expose:

- `aegis_doctor`
- `aegis_plugin_doctor`
- `aegis_policy_check`
- `aegis_policy_explain`
- `aegis_redteam`
- `aegis_replay_summary`
- `aegis_capabilities`
- `aegis_drone_safety_status`

It must not expose by default:

- arbitrary shell execution
- arbitrary file writes
- raw audit log dumping
- live drone actuation
- credential access
- policy mutation without explicit approval
