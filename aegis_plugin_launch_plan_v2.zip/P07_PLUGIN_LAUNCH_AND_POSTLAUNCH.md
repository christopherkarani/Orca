# P07 — Plugin Launch and Post-launch

## Objective

Launch the Aegis plugin system publicly and prepare for fast post-launch patching.

---

## Effort

**Recommended effort:** Medium

Use High only if security or drone-safety issues are found.

---

## Scope

Implement or prepare:

- plugin release notes
- launch announcement
- README updates
- plugin demo
- issue templates
- compatibility tracking
- post-launch triage labels
- first patch checklist

---

## Release Notes

Create:

```text
PLUGIN_RELEASE_NOTES.md
```

Sections:

- Aegis CLI plugin surface
- Codex plugin
- Claude Code plugin
- drone safety note
- install
- verify
- demo
- known limitations
- security model
- vulnerability reports

Required sentence:

```text
The strongest protection remains running the agent through `aegis run`; plugins provide native commands, hooks, and guardrails inside supported agent hosts.
```

---

## Demo

Create:

```text
examples/plugin-demo/
  README.md
  codex-demo.md
  claude-demo.md
  drone-safety-demo.md
  fake-hook-payloads/
```

Drone demo must be simulation-only and must not operate real hardware.

---

## Issue Templates

Create/update:

```text
.github/ISSUE_TEMPLATE/codex_plugin_bug.md
.github/ISSUE_TEMPLATE/claude_plugin_bug.md
.github/ISSUE_TEMPLATE/aegis_cli_plugin_bug.md
.github/ISSUE_TEMPLATE/plugin_security_bug.md
.github/ISSUE_TEMPLATE/drone_safety_regression.md
.github/ISSUE_TEMPLATE/plugin_compatibility.md
```

---

## Triage Labels

Suggested labels:

```text
plugin:codex
plugin:claude
plugin:cli
plugin:hooks
plugin:mcp
plugin:install
plugin:marketplace
plugin:security
plugin:drone-safety
plugin:compatibility
plugin:docs
```

---

## Launch Checklist

- GitHub release includes plugin artifacts.
- Install docs work.
- Plugin doctor works.
- Codex plugin local install tested or documented.
- Claude plugin local/marketplace install tested or documented.
- Secret scan passes.
- Drone safety demo is simulation-only.
- Docs do not overclaim.
- Known limitations are clear.

---

## Acceptance Criteria

- Release notes exist.
- Launch announcement exists.
- Demo docs exist.
- Issue templates exist.
- Triage labels list exists.
- GitHub release checklist exists.
- Plugins are ready to publish.

---

## Codex Execution Prompt

```text
Implement P07: Plugin Launch and Post-launch.

Prepare plugin release notes, launch docs, README links, plugin demos, drone-safety demo, issue templates, triage labels, and first patch checklist. Do not add new product features.

Run:
- zig build
- zig build test
- plugin tests
- secret scan
- docs link validation if available

Recommended effort: Medium.
```
